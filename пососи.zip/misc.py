import asyncio
from data import config, db
from aiogram import Bot, Dispatcher, types

loop = asyncio.get_event_loop()
bot = Bot(token=config.bot_token, parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot=bot, loop=loop)
