from aiogram import types
from data import config, db

def Uid(item: types.Message or types.CallbackQuery or int):
	if isinstance(item, types.Message):
		return "U" + str(item.chat.id)
	elif isinstance(item, types.CallbackQuery):
		return "U" + str(item["from"].id)
	else:
		return "U" + str(item)

def new_msg(message):
	uid = Uid(message)
	count = get_value(message, "total")
	edit_value(uid, "total", count+1)

def check_in_db(module: callable):
	async def substitute(message: types.Message):
		uid = Uid(message)
		users = db.get("users", {})
		
		if not uid in users:
			users[uid] = {
				"id": message.chat.id,
				"dialog": None,
				"status": 0
			}
			db.set("users", users)
		await module(message)
	return substitute

def edit_value(uid, value, new):
	users = db.get("users")
	users[uid][value] = new
	db.set("users", users)

def get_value(item, value):
	uid = Uid(item)
	users = db.get("users")
	return users[uid][value]

def get_status(item):
	uid = Uid(item)
	return db.get("users")[uid]["status"]

async def delete_dialog(message: types.Message):
	me_uid = Uid(message)
	dialog_id = db.get("users")[me_uid]["dialog"]
	dialog_uid = Uid(dialog_id)
	
	edit_value(me_uid, "status", 0)
	edit_value(dialog_uid, "status", 0)

	await message.answer(
		config.end_text,
		reply_markup=config.main_key
	)
	await message.bot.send_message(dialog_id, config.uend_text, reply_markup=config.main_key)

async def stop_search(message: types.Message):
	uid = Uid(message)
	edit_value(uid, "status", 0)

async def search_dialog(message: types.Message):
	me = Uid(message)
	users = db.get("users")
	
	if users[me]["status"] == 1:
		await message.reply("Ты ужё ищешь")
		return
	elif users[me]["status"] == 2:
		await delete_dialog(message)
		
	edit_value(me, "status", 1)
	users = db.get("users")
	
	for uid in users:
		if users[uid]["status"] == 1 and users[uid]["id"] != message.chat.id:
			edit_value(uid, "status", 2)
			edit_value(uid, "dialog", message.chat.id)
			edit_value(me, "dialog", users[uid]["id"])
			edit_value(me, "status", 2)

			await message.answer(config.done_text, reply_markup=config.dialog_key)
			return await message.bot.send_message(users[uid]["id"], config.done_text, reply_markup=config.dialog_key)
			
	await message.answer(config.last_text, reply_markup=config.nosearch_key)

def get_reply_id(chat_id, msg_id):
	data = db.get("reply")
	
	for msg in data:
		for i in msg["msg"]:
			if i["chat_id"] == chat_id and i["msg_id"] == msg_id:
				return msg["msg"]

def search_reply(chat_id, reply):
	if not reply:
		return
	elif isinstance(reply, int):
		return
	else:
		for data in reply:
			if data["chat_id"] == chat_id:
				return data["msg_id"]
	return

def save_reply(chat_id, msg_id, message):
	data = {"msg": []}
	reply = db.get("reply")
	data["msg"].append({
		"chat_id": chat_id,
		"msg_id": msg_id
	})
	data["msg"].append({
		"chat_id": message.chat.id,
		"msg_id": message.message_id
	})
	reply.append(data)
	db.set("reply", reply)
