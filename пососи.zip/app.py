import asyncio
import utils
import sys
import os

from misc import bot, dp
from aiogram import types, executor
from data.config import *

@dp.message_handler(commands=["start"])
@utils.check_in_db
async def hello(message: types.Message):
	status = utils.get_status(message)
	if status == 0:
		keyboard = main_key
	elif status == 1:
		keyboard = nosearch_key
	else:
		keyboard = dialog_key
	
	await message.answer(
		hello_text, reply_markup=keyboard
	)

@dp.message_handler(text=["🔎 Поиск собеседника"])
@utils.check_in_db
async def search(message: types.Message):
	status = utils.get_status(message)
	if status == 0:
		await utils.search_dialog(message)
	elif status == 1:
		await message.answer(
			postkj_text, reply_markup=nosearch_key
		)
	else:
		await message.answer(
			yje_text, reply_markup=dialog_key
		)
	
@dp.message_handler(text=["🚫 Остановить диалог"])
@utils.check_in_db
async def stop_dialog(message: types.Message):
	status = utils.get_status(message)
	if status == 0:
		await message.answer(
			nedialog_text, reply_markup=main_key
		)
	else:
		await utils.delete_dialog(message)

@dp.message_handler(text=["🚫 Остановить поиск"])
@utils.check_in_db
async def stop_search(message: types.Message):
	status = utils.get_status(message)
	if status == 1:
		await utils.stop_search(message)
		await message.answer(
			nolast_text,
			reply_markup=main_key
		)
	else:
		await message.answer(
			nelast_text,
			reply_markup=main_key
		)

@dp.message_handler(text=["📣 Новости"])
@utils.check_in_db
async def news(message: types.Message):
	await message.answer(
		"📻 <b>Наш канал с новостями:</b> <a href=\"t.me/ew1r3zt\">*тык*</a>"
	)

@dp.message_handler(text=["🗒️ Правила"])
@utils.check_in_db
async def rules(message: types.Message):
	await message.answer(rules_text)

@dp.message_handler(text=["📬 Реклама"])
@utils.check_in_db
async def piar(message: types.Message):
	await message.answer(
		"⚡ <b>Проект открыт к рекламным предложениям\n\n🔒 Наши контакты:</b> @dentlysempaiz"
	)

@dp.message_handler(text=["📚 О боте"])
@utils.check_in_db
async def about(message: types.Message):
	users = utils.db.get("users")
	
	await message.answer(
		stats_text % len(users)
	)

@dp.message_handler(commands=["purge"])
@utils.check_in_db
async def purge(message: types.Message):
	utils.db.set("reply", [])
	await message.answer("Succes")

@dp.message_handler(content_types=types.ContentTypes.all())
@utils.check_in_db
async def all(message: types.Message):
	status = utils.get_status(message)
	
	if status != 2:
		return
	else:
		dialog = utils.get_value(message, "dialog")
		if message.reply_to_message:
			reply = utils.get_reply_id(message.chat.id, message.reply_to_message.message_id)
			
			id = utils.search_reply(dialog, reply)
			msg = await message.copy_to(dialog, reply_to_message_id=id)
		else:
			msg = await message.copy_to(dialog)

		utils.save_reply(dialog, msg.message_id, message)

async def restart(*args, **kwargs):
	utils.db.set("reply", [])
	os.execl(sys.executable, sys.executable, *sys.argv)

if __name__ == "__main__":
	executor.start_polling(dp, skip_updates=True, on_shutdown=restart)
