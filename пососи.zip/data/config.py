from aiogram.types import (
	ReplyKeyboardMarkup, KeyboardButton
)

bot_token = "2122922722:AAGiYg0qo9suZw7k5tM35mI3d_d3vLWIZmk"

hello_text = "👋 <b>Добро пожаловать! Главное меню:</b>"
last_text = "⏳ <b>Вы добавлены в очередь поиска, ожидайте собеседника!</b>"
done_text = "❤️ <b>Собеседник найден, желаем приятного общения!</b>"
yje_text = "💬 <b>Ошибка! Вы уже находитесь в диалоге!</b>"
postkj_text = "🕒 <b>Ошибка! Вы уже в поиске собеседника!</b>"
nedialog_text = "🔐 <b>Ошибка! Вы не в диалоге!</b>"
end_text = "🙄 <b>Вы закончили связь с вашим собеседником!</b>"
uend_text = "😞 <b>Собеседник закончил с вами связь!</b>"
nolast_text = "🔌 <b>Вы вышли из очереди!</b>"
nelast_text = "🤕 <b>Ошибка! Вы не ищите собеседника!</b>"
stats_text = "📊 <b>Статистика бота\n\n👥 Пользователей в боте:</b> %s\n🕐 <b>Бот работает с:</b> 21.11.2021\n👮🏼‍♂️ <b>Администратор:</b> @dentlysempaiz"

rules_text = """🚫 <b>Запрещено распространять:

— Порнографический контент.
— Оружие, наркотики, психотропные вещества.
— Сообщения призывающие к суициду.
— Сообщения призывающие к массовым беспорядкам.
— Оскорбительные сообщения.
— Экстремистский контент.
— Любые иные вещи, документы или информацию запрещенную к распространению законодательством.</b>"""

main_key = ReplyKeyboardMarkup(resize_keyboard=True).add(
	KeyboardButton("🔎 Поиск собеседника")
).add(
	KeyboardButton("📣 Новости"),
	KeyboardButton("🗒️ Правила")
).add(
	KeyboardButton("📬 Реклама"),
	KeyboardButton("📚 О боте")
)

nosearch_key = ReplyKeyboardMarkup(resize_keyboard=True).add(
	KeyboardButton("🚫 Остановить поиск")
).add(
	KeyboardButton("📣 Новости"),
	KeyboardButton("🗒️ Правила")
).add(
	KeyboardButton("📬 Реклама"),
	KeyboardButton("📚 О боте")
)

dialog_key = ReplyKeyboardMarkup(resize_keyboard=True).add(
	KeyboardButton("🚫 Остановить диалог")
)