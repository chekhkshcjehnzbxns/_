from . import config
from lightdb import LightDB

db = LightDB("data/db.json")
